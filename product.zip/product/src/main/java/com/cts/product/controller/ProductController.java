package com.cts.product.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.product.bean.Category;
import com.cts.product.bean.Product;
import com.cts.product.service.CategoryService;
import com.cts.product.service.ProductService;



@Controller
public class ProductController {
	
	
	@Autowired
	//@Qualifier("productService")
	ProductService productService;
	
	
	@Autowired
	CategoryService categoryService;
	
	@RequestMapping("Admin-AddProduct.html")
	public String getAdminAddProduct(){
		return "Admin-AddProduct";
	}
	
//	@RequestMapping("Admin-ListProducts.html")
//	public String getAddProduct(){
//		return "Admin-ListProducts";
//	}
	

	
	@RequestMapping("Admin-AddProduct12.html")
	public ModelAndView displayCategory(@ModelAttribute Product product){
		//session
		ModelAndView modelAndView = new ModelAndView();
		List<Category> category = categoryService.getCategoryName();
		System.out.println(category);
		modelAndView.addObject("category", category);
		modelAndView.setViewName("Admin-AddProduct");
		return modelAndView;
		
	}
	
	@RequestMapping(value="Admin-AddProduct.html",method = RequestMethod.POST)
	public ModelAndView addProduct(@ModelAttribute Product product){
		//session
		
		ModelAndView modelAndView = new ModelAndView();
		
		
		if("true".equals(productService.insertProduct(product)))
		{
			System.out.println(product);
			modelAndView.setViewName("productAddSuccess");
		}
		else 
		{
			modelAndView.setViewName("productAddFailed");
		}
		return modelAndView;
		
	}
	


}
